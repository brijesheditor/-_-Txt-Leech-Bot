from bot import Bot

if __name__ == '__main__':
    Bot().run()